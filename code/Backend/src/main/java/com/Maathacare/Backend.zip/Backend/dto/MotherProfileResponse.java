package com.Maathacare.Backend.dto;

import java.time.LocalDate;

public class MotherProfileResponse {
    private String fullName;
    private String nic;
    private LocalDate dateOfBirth;
    private LocalDate lastMenstrualPeriod;
    private String address;
    private String emergencyContactNumber;
    private String bloodGroup;
    private String district;
    private String province;
    private String phmName;
    private String phmId;
    private String emergencyContactName;
    private String emergencyContactRelationship;
    private String profilePictureUrl;
    private String mohArea;
    private String gnDivision;

    // --- Getters and Setters ---
    // These allow the app to read and write the data

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getNic() { return nic; }
    public void setNic(String nic) { this.nic = nic; }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public LocalDate getLastMenstrualPeriod() { return lastMenstrualPeriod; }
    public void setLastMenstrualPeriod(LocalDate lastMenstrualPeriod) {
        this.lastMenstrualPeriod = lastMenstrualPeriod;
    }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getEmergencyContactNumber() { return emergencyContactNumber; }
    public void setEmergencyContactNumber(String emergencyContactNumber) { this.emergencyContactNumber = emergencyContactNumber; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getProvince() { return province; }
    public void setProvince(String province) { this.province = province; }

    public String getPhmName() {
        return phmName;
    }

    public void setPhmName(String phmName) {
        this.phmName = phmName;
    }

    public String getPhmId() {
        return phmId;
    }

    public void setPhmId(String phmId) {
        this.phmId = phmId;
    }

    public String getEmergencyContactName() { return emergencyContactName; }
    public void setEmergencyContactName(String emergencyContactName) { this.emergencyContactName = emergencyContactName; }

    public String getEmergencyContactRelationship() { return emergencyContactRelationship; }
    public void setEmergencyContactRelationship(String emergencyContactRelationship) { this.emergencyContactRelationship = emergencyContactRelationship; }

    public String getProfilePictureUrl() { return profilePictureUrl; }
    public void setProfilePictureUrl(String profilePictureUrl) { this.profilePictureUrl = profilePictureUrl; }

    public String getMohArea() { return mohArea; }
    public void setMohArea(String mohArea) { this.mohArea = mohArea; }

    public String getGnDivision() { return gnDivision; }
    public void setGnDivision(String gnDivision) { this.gnDivision = gnDivision; }
}
